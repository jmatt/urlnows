#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <memory.h>
#include <stdio.h>
#include <stdlib.h>

#include "sqlite3.h"

typedef struct struct_connection {
  struct sockaddr_in address;
  socklen_t          length;
  int                handle;
  int                starting;
  pid_t              me;
} connection;

int receive( connection c, char * buffer, int length )
{
  return recvfrom( c.handle, buffer, length, 0,
		   (struct sockaddr *)&c.address, &c.length );
}

int transmit( connection c, char * buffer, int length )
{
  return sendto( c.handle, buffer, length, 0,
		 (struct sockaddr *)&c.address, sizeof( c.address ) );
}

#define SEND_OK  transmit( client, "200\r\n", 5 );
#define SEND_ERR(e) send_err( client, e );

void send_err( connection client, char * e )
{
  char buffer[1024]; 
  sprintf( buffer, "\"500 %s\"\r\n", e ); 
  transmit( client, buffer, strlen( buffer ));
}

int callback( void * param, int count, char** row, char** columns )
{

  connection client = *(connection *)param;
 
  if ( client.starting == 1 ) {
    SEND_OK
    ((connection *)param)->starting = 0;
  }

  int i;
  int length = 0;

  for ( i = 0; i < count; ++i ) {
    length += strlen( row[i] );
  }

  length += count * 2;
  length += count;
  length += 6;

  char * buffer = (char *)malloc( length + 1 );

  sprintf( buffer, "(" );

  for ( i = 0; i < count; ++i ) {
    strcat( buffer, "\"" );
    strcat( buffer, row[i] );
    strcat( buffer, "\" " );
  }

  strcat( buffer, ")" );

  printf( "%d > %s\n", client.me, buffer );

  strcat( buffer, "\r\n" );

  transmit( client, buffer, strlen( buffer ) );

  free( buffer );

  return SQLITE_OK;
}

int main( int argc, char * argv[] ) 
{
  int port = (argc < 2)?0xC001:atoi( argv[1] );

  printf( "sqarc listening on port %d\n", port );

  int listener;
  struct sockaddr_in servaddr;

  listener = socket( AF_INET, SOCK_STREAM, 0 );

  bzero( &servaddr, sizeof( servaddr ) );
  servaddr.sin_family      = AF_INET;
  servaddr.sin_addr.s_addr = htonl( INADDR_ANY );
  servaddr.sin_port        = htons( port );
  bind( listener, (struct sockaddr *)&servaddr, sizeof( servaddr ) );

  listen( listener, 1024 );

  while ( 1 ) {
    pid_t     pid;

    struct sockaddr_in cliaddr;
    socklen_t clilen = sizeof( cliaddr );
    int clienth = accept( listener, (struct sockaddr *)&cliaddr, &clilen );
    
    if ( ( pid = fork() ) == 0 ) {
      close( listener );

      connection client;
      client.address = cliaddr;
      client.length = clilen;
      client.handle = clienth;

      pid_t me = getpid();
      client.me = me;

      printf( "Child %d started\n", me );

#define MAX_COMMAND 1024
      char command[MAX_COMMAND];
      int n = receive( client, command, MAX_COMMAND );

      if ( n > 4 ) {
	sqlite3 * db;

	command[n-3] = 0;
	if ( sqlite3_open( &command[1], &db ) == SQLITE_OK ) {
	  SEND_OK

	  printf( "%d < %s\n", me, &command[1] );

	  while (1) {
	    n = receive( client, command, MAX_COMMAND );

	    if ( n <= 4 ) {
	      break;
	    }

	    command[n-3] = 0;

	    printf( "%d < %s\n", me, &command[1] );

	    client.starting = 1;
	    char * error;
	    if ( sqlite3_exec( db, &command[1], callback, &client, &error ) !=
		 SQLITE_OK ) {
	      SEND_ERR(error)
	    } else {
	      if ( client.starting ) {
		SEND_OK
	      }
	      SEND_OK
	    }
	  }
	} else {
	  SEND_ERR("Database connect failed")
	}

	sqlite3_close( db );
      } else {
	SEND_ERR("Bad database name")
      }

      printf( "Child %d stopped\n", me );
      exit(0);
    }

    close( clienth );
  }
}
